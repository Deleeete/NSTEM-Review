import requests
import random
import json
from random import choice
from time import sleep

def send(data):
    payload = data
    r = requests.post("http://127.0.0.1:6221/", data=payload, stream=False)
    r.close()
    return r.text

def echo(data):
    re = send("echo("+data+")")
    print("回音测试 -- " + re)
    return

def set_name(name):
    response_str = send("set_name("+name+")")
    print("设置名字 -- " + response_str)

def isMyTurn():
    response_str = send("get_isMyTurn")
    re = json.loads(response_str)
    return re

def board():
    response_str = "{" + send("get_board") + "}"
    b = json.loads(response_str)
    return b

def moves():
    mvs = json.loads(send("get_moves"))
    return mvs

def place(pick):
    state = send("["+str(pick[0])+","+str(pick[1])+"]")
    print("落子 -- " + str(pick))
    return state

def winner():
    re_str = send("get_winner")
    return json.loads(re_str)
