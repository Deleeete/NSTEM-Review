import requests
import random
import json
import gu   
from random import choice
from time import sleep

gu.echo("Hello, i am Scoreo!")             # 回音测试。如果打印结果和参数相同说明连接正常。注意，如果参数包括中文的话，必须先用UTF8或者同类方法编码。

gu.set_name("Scoreo")                           # 设置AI的名字。调用其它任何API之前必须先设好名字。只可以设置一次。

while gu.winner() == 'none':               # winner()返回游戏赢家，有三个可能的值：'none'表示游戏还没结束，'white'和'black'分别指白方和黑方。

    if gu.isMyTurn() == 'True' :                # isMyTurn()返回字符串，有两个可能的值：'True'表示当前轮到这个AI，接下来的落子将生效；‘False’表示当前轮到另一方，落子会被忽略。

        sleep(2)                        # 挂起两秒，不然人都还没看清楚自己下的效果是啥 AI就先下了。

        current_board = gu.board()              # board()返回代表当前棋盘的[8,8]数组，每个元素有三种可能的值：'none'表示空位，'white'和'black'分别指白棋和黑棋。

        current_moves = gu.moves()       # moves()返回当前棋盘可以下的所有位置，形式为由多个{x,y}组成的数组。坐标使用左上坐标系。

        pick = choice(current_moves)            # 这个脑瘫AI简单地从上面所有可能的位置里面随机选一个。（但是，在可行的位置落子本身并不是绝对必要的——只不过在其它地方下了也会被忽略掉。）

        gu.place(pick)                   # place()接收一个int[2]参数，在坐标[0],[1]处落子。坐标使用左上坐标系。

    sleep(0.2)                                 # AI两次检查是否轮到自己 的时间间隔为0.2s。

if gu.winner() == 'white':
    print('俺赢了')
else:
    print('俺输了')